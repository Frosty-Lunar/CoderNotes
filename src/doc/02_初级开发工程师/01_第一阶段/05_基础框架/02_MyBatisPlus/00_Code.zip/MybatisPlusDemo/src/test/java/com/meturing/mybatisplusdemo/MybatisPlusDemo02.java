package com.meturing.mybatisplusdemo;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.meturing.mybatisplusdemo.pojo.User;
import com.meturing.mybatisplusdemo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

@SpringBootTest
public class MybatisPlusDemo02 {
    @Autowired
    @Qualifier("userServiceImpl")
    public UserService userService;

    @Test
    public void test() {
        List<User> list = userService.list();
        list.forEach(System.out::println);
    }

    //精确查询
    @Test
    public void test1(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.like("name", "J").gt("age",18).isNotNull("email");
        List<User> list = userService.list(userQueryWrapper);
        list.forEach(System.out::println);
    }

    //排序
    @Test
    public void test2(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.orderByAsc("age").orderByDesc("uid");
        List<User> list = userService.list(userQueryWrapper);
        list.forEach(System.out::println);
    }

    //删除年龄大于等于28的
    @Test
    public void test3(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.ge("age",28);
        boolean remove = userService.remove(userQueryWrapper);
    }

    /**
     * 查询出年龄大于20并且姓名中包含的有'o'或者邮箱地址为空的记录
     */
    @Test
    public void test4(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.ge("age", 20).like("name", "o").or().isNull("email");
        List<User> list = userService.list(userQueryWrapper);
        list.forEach(System.out::println);
    }

    @Test
    public void test5(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.and((s)->{s.ge("age", 20).like("name", "o");})
                .or((s)->{s.isNull("email");});
        List<User> list = userService.list(userQueryWrapper);
        list.forEach(System.out::println);
    }


    //查询特定的字段
    @Test
    public void test6(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.like("name", "J").select("name","age");
        //返回Map集合列表，通常配合select()使用，避免User对象中没有被查询到的列值为null
        List<Map<String, Object>> maps = userService.listMaps(userQueryWrapper);
        maps.forEach(System.out::println);
    }

    //实现子查询
    @Test
    public void test7(){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.inSql("id","select id from t_user where id < 5");
        List<User> list = userService.list(userQueryWrapper);
        list.forEach(System.out::println);
    }

    //UpdateWrapper
    @Test
    public void test8(){
        UpdateWrapper<User> wrapper = new UpdateWrapper<>();
        //将年龄为33的用户更改
        wrapper.set("age",25).set("name", "2333").set("email","xx@xx.xx").set("isdel", "0").and(s->{s.eq("age",33);});
        boolean update = userService.update(null, wrapper);
    }

    //动态SQL
    @Test
    public void test9(){
        String  name = "Tom";
        Integer age = null;
        String email = null;
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        if(!StringUtils.isEmpty(name)){
            wrapper.eq("name",name);
        }
        if(age != null && age > 0){
            wrapper.eq("age",age);
        }
        if(!StringUtils.isEmpty(email)){
            wrapper.eq("email",email);
        }
        List<User> users = userService.list(wrapper);
        users.forEach(System.out::println);
    }
    @Test
    public void test10(){
        String  name = "Tom";
        Integer age = null;
        String email = null;
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq(!StringUtils.isEmpty(name),"name",name)
                .eq(age != null && age > 0,"age",age)
                .eq(!StringUtils.isEmpty(email),"email",email);
        List<User> users = userService.list(wrapper);
        users.forEach(System.out::println);
    }

    @Test
    void queryPage() {
        Page<User> page = new Page<>(1,5);
        Page<User> userPage = userService.page(page,null);
        System.out.println("userPage.getCurrent() = " + userPage.getCurrent());
        System.out.println("userPage.getSize() = " + userPage.getSize());
        System.out.println("userPage.getTotal() = " + userPage.getTotal());
        System.out.println("userPage.getPages() = " + userPage.getPages());
        System.out.println("userPage.hasPrevious() = " + userPage.hasPrevious());
        System.out.println("userPage.hasNext() = " + userPage.hasNext());
    }
}
