package com.meturing.mybatisplusdemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
//@TableName("t_user")
public class User {
    @TableId(value = "id",type = IdType.AUTO)//表示主键 并重新映射到Id字段,分配主键自增
    private Long uid;
    @TableField(value = "name")// 表结构中的name属性和name属性对应
    private String uname;
    private Integer age;
    private String email;
    @TableLogic(value = "0",delval = "1")//逻辑删除,默认为0 删除后为1
    private Integer isdel;

    public User(String uname, Integer age, String email) {
        this.uname = uname;
        this.age = age;
        this.email = email;
    }

    public User(Long uid, String uname, Integer age, String email) {
        this.uid = uid;
        this.uname = uname;
        this.age = age;
        this.email = email;
    }
}
