package com.meturing.mybatisplusdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.meturing.mybatisplusdemo.pojo.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * MyBatisPlus中的Mapper接口继承自BaseMapper，同时指定对应的实体类
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

}
