package com.meturing.mybatisplusdemo.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.meturing.mybatisplusdemo.mapper.UserMapper;
import com.meturing.mybatisplusdemo.pojo.User;
import com.meturing.mybatisplusdemo.service.UserService;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

}
