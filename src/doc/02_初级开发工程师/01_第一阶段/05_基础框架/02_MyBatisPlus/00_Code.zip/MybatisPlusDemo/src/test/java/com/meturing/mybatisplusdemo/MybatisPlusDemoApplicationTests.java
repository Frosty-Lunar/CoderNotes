package com.meturing.mybatisplusdemo;

import com.meturing.mybatisplusdemo.mapper.UserMapper;
import com.meturing.mybatisplusdemo.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@SpringBootTest
class MybatisPlusDemoApplicationTests {
    @Autowired
    private UserMapper userMapper;

    /**
     * 查询所有
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void selectUser1() {
        List<User> users = userMapper.selectList(null);
        users.forEach(System.out::println);
    }

    /**
     * 根据ID查询
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void selectUser2() {
        User user = userMapper.selectById(5L);
        System.out.println(user);
    }

    /**
     * 根据Map查询
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void selectUser3() {
        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("age",24);
        userMap.put("name","Billie");
        List<User> users = userMapper.selectByMap(userMap);
        users.forEach(System.out::println);
    }

    /**
     * 添加用户
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void addUser(){
        User user = new User(6L,"张三",28,"xxxx@xx.com");
        int insertRows = userMapper.insert(user);
        System.out.println(insertRows);
    }

    /**
     * 根据ID删除用户
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void deleteUser1(){
        User user = new User(6L,"李四",15,"xxxx@xx.com");
        int deleteRows = userMapper.deleteById(user);
        System.out.println(deleteRows);
    }

    /**
     * 根据ID删除用户
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void deleteUser2(){
        int deleteRows = userMapper.deleteBatchIds(Arrays.asList(6L,1648197837407772673L,1648197837445521409L));
        System.out.println(deleteRows);
    }

    /**
     * 根据ID删除用户
     *
     * @author sqTan
     * @date 2023/04/18
     */
    @Test
    public void deleteUser3(){
        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("age",15);
        userMap.put("name","张三");
        int deleteRows = userMapper.deleteByMap(userMap);
        System.out.println(deleteRows);
    }

    @Test
    public void updateUser1(){
        User user = new User(6L,"李四",15,"xxxx@xx.com");
        int updateRows = userMapper.updateById(user);
        System.out.println(updateRows);
    }
}
