package com.meturing.mybatisplusdemo;

import com.meturing.mybatisplusdemo.pojo.User;
import com.meturing.mybatisplusdemo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
public class MybatisPlusDemo01 {
    @Autowired
    @Qualifier("userServiceImpl")
    public UserService iUserService;

    @Test
    public void test(){
        User byId = iUserService.getById(5L);
        System.out.println(byId);
    }

    @Test
    public void testCount(){
        long count = iUserService.count();
        System.out.println(count);
    }

    @Test
    public void testSeelctAll(){
        List<User> users = iUserService.list(null);
        users.forEach(System.out::println);
    }

    @Test
    public void batchInserts(){
        List<User> users = Arrays.asList(new User( "王五", 22, "111@111.com"),
                new User( "赵六", 33, "222@222.com"));
        boolean b = iUserService.saveBatch(users);
        System.out.println(b);
    }

    @Test
    public void testSave(){
        User wangwu = new User("wangwu", 25, "111@xxx.xx");
        boolean save = iUserService.save(wangwu);
    }
}
