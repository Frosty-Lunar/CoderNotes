package com.meturing.mybatisplusdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.meturing.mybatisplusdemo.pojo.User;

public interface UserService extends IService<User> {

}
